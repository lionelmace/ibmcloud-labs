var todoApp = angular.module('todoApp', [
  // Module dependencies
  'todoController', 'todoService'
]);
